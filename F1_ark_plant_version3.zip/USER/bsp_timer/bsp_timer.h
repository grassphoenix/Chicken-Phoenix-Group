#ifndef  __BSP_TIMER_H
#define  __BSP_TIMER_H
#include "stm32f10x.h"
void stepping1_tim6_init(u16 arr,u16 psc);
void  encoder1_tim2_init(void);
void encoder2_tim3_init(void);
void  encoder3_tim4_init(void);
void  encoder4_tim5_init(void);
void stepping1_tim6_init(u16 arr,u16 psc);
void stepping2_tim7_init(u16 arr,u16 psc);
void PWM_timer8_Init(u16 arr,u16 psc);
void timer1_Init(u16 arr,u16 psc);
#endif