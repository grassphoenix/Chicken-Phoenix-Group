#ifndef BSP_ENCODER_H
#define BSP_ENCODER_H
#include "stm32f10x.h"

void encoder_scanf(void);
#endif
