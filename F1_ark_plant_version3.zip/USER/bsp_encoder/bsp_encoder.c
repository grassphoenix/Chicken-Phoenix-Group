#include "bsp_encoder.h"
#include "usart.h"
#include "bsp_pid.h"
extern motor_control moto[4];
extern int j1,j2,j3,j4;
int encoder_state1=0;
int encoder_state2=0;
int encoder_state3=0;
int encoder_state4=0;
int encoder_state5=0;
int encoder_state6=0;
int encoder_state7=0;
int encoder_state8=0;
int cnt1,cnt2,cnt3,cnt4;
void encoder_scanf()
{
			moto[0].sum_count=moto[0].count*64999+TIM_GetCounter(TIM2);
			moto[1].sum_count=moto[1].count*64999+TIM_GetCounter(TIM3);
			moto[2].sum_count=moto[2].count*64999+TIM_GetCounter(TIM4);
			moto[3].sum_count=moto[3].count*64999+TIM_GetCounter(TIM5);
}