#include "bsp_pid.h"
#include "usart.h"
#include "bsp_wheel.h"
#include "usart3.h"
#include "delay.h"
/*
  **PWM���ΪTIM4
	**
	*/



extern motor_control moto[4];	
extern int circle_count1;//����1��Ȧ�٣���������Ϊ1MHZ
extern int last_circle_count1;//����1����һ�ּ���Ȧ������������Ϊ0.1s/��
extern int compare1;//���μ���Ȧ����ֵ
int x;
int PIDj=0;//PID����
int PIDk=1;
int PID_time_count=0;//�����˼���
int PID_Integral;//ͬ��
float pwmcount;
PosCtrlType PosCtrlType1;
float integral;
int error;//Ԥ���뵱ǰֵ�Ĳ�ֵ

void brake(int set_count)
{ 	

//	x=0;//ֹͣ��־λ
//	
//	PosCtrlType1.kd=0.03;
//	PosCtrlType1.kp =2.6;
//	PosCtrlType1.ki=0.02378;
//	int dutyratio;//ռ�ձ�
//	int start=6;//��ǰɲ��ֵ
//	int range=7;//��Χ
//	
//	PosCtrlType1.speed =compare1/(float)0.01;//�ٶ�
//	PosCtrlType1.set_point=set_count;//�趨ֵ
//  integral=integral+error;//������
//	error=set_count-circle_count1;
//	PosCtrlType1.accelerated_speed = (PosCtrlType1.speed-PosCtrlType1.last_speed)/(float)0.01;//���ٶ�
//	if(PosCtrlType1.speed<0)//ȷ���ٶ�Ϊ����ֵ
//		PosCtrlType1.speed=-PosCtrlType1.speed;
//	if(integral<0)//ȷ���ٶ�Ϊ����ֵ
//		integral=-integral;
////	/*ֹͣ����,��־λ��1*/
////	if((compare1<=20&&compare1>0)|(compare1>=-20&&compare1<0))//ֹͣ���ٶȣ���ȻĦ�����䵱���ٶ�
////		{
////			if((compare1>=-5&&compare1<0))
////			{wheel_stop();
////		tim4_pwm_control(0,1);
////		x=1;
////			}
////			
////			if(compare1<=5&&compare1>0)
////			{wheel_stop();
////		tim4_pwm_control(500,1);
////		x=1;
////			}
////			printf("yes\n\r\n\r");
////	
////		}
//			
//		if(set_count+range>=circle_count1&&circle_count1>=set_count-range)
//		{
//			wheel_stop();
//		tim4_pwm_control(500,1);
//		x=1;
////  printf("yes\n\r\n\r");
//		}
//	
//	if(PosCtrlType1.set_point>=0&&x==0)
//	{ 
//		
////		if(x!=1)
////		{
//		PosCtrlType1.output=PosCtrlType1.kp*error-PosCtrlType1.kd*PosCtrlType1.speed;		
//		
//		/*�޶���ʱ���Ƚ�ֵ*/
//		if(PosCtrlType1.output>=500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=499;
//		if(PosCtrlType1.output<=-500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=-499;
//		
//		if(circle_count1>=PosCtrlType1.set_point-start)
//		{ 
//			wheel_stop();
//		  PosCtrlType1.output=PosCtrlType1.kp*error+PosCtrlType1.kd*PosCtrlType1.speed-PosCtrlType1.ki*integral;
//			if(PosCtrlType1.output>0)
//			PosCtrlType1.output=499;
//			if(PosCtrlType1.output<=-500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=499;
//			
//			tim4_pwm_control(PosCtrlType1.output,1);
//			wheel_back();
//			

//		}
//		
//		if(circle_count1<PosCtrlType1.set_point-start)
//		{ 
//			wheel_stop();
////			printf("%f\n\r\n\r",integral);
//	    PosCtrlType1.output=PosCtrlType1.kp*error+PosCtrlType1.kd*PosCtrlType1.speed+PosCtrlType1.ki*integral;
//			/*�޶���ʱ���Ƚ�ֵ*/
//		if(PosCtrlType1.output>=500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=499;
//    printf("output=====%d\n\r\n\r",PosCtrlType1.output);
//			tim4_pwm_control(500-PosCtrlType1.output,1);
//		  wheel_staight();
//		}
//		
////		}
//	
//	}
//	
//	if(PosCtrlType1.set_point<0&&x==0)
//	{
//		
//		PosCtrlType1.output=PosCtrlType1.kp*error+PosCtrlType1.kd*PosCtrlType1.speed;		
//		
//		/*�޶���ʱ���Ƚ�ֵ*/
//		if(PosCtrlType1.output>=500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=499;
//		if(PosCtrlType1.output<=-500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=-499;
//		
//		if(circle_count1<=PosCtrlType1.set_point+start)
//		{
//			wheel_stop();
//		  PosCtrlType1.output=PosCtrlType1.kp*error+PosCtrlType1.kd*PosCtrlType1.speed+PosCtrlType1.ki*integral;
//			if(PosCtrlType1.output<0)
//			PosCtrlType1.output=500;
//			if(PosCtrlType1.output>=500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=499;
//			tim4_pwm_control(500-PosCtrlType1.output,1);
//			wheel_staight();
//		}
//		
//		if(circle_count1>PosCtrlType1.set_point+start)
//		{
//	    PosCtrlType1.output=PosCtrlType1.output+PosCtrlType1.ki*integral;
//			
//			if(PosCtrlType1.output>=500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=499;
//		if(PosCtrlType1.output<=-500)//�޶��Ƚ�ֵ
//			PosCtrlType1.output=-499;
//		
//			tim4_pwm_control(PosCtrlType1.output,1);
//		  wheel_back();
//		}
//	}//�д��Ľ�
//	 //JUME_7th have been change the pwm cunt,have not yet update.
//	
//	
//	PosCtrlType1.last_speed =PosCtrlType1.speed;

}

void PID_dispose()
{
	

moto[0].ActualSpeed =(moto[0].sum_count -moto[0].last_sum_count); 
moto[1].ActualSpeed =(moto[1].sum_count -moto[1].last_sum_count); 
moto[2].ActualSpeed =(moto[2].sum_count -moto[2].last_sum_count); 	
moto[3].ActualSpeed =(moto[3].sum_count -moto[3].last_sum_count); 

moto[0].NowError=moto[0].set_speed-moto[0].ActualSpeed; 
moto[1].NowError=moto[1].set_speed-moto[1].ActualSpeed; 
moto[2].NowError=moto[2].set_speed-moto[2].ActualSpeed; 
moto[3].NowError=moto[3].set_speed-moto[3].ActualSpeed; 
	
moto[0].Integral_speed=moto[0].Integral_speed+moto[0].NowError;
moto[1].Integral_speed=moto[1].Integral_speed+moto[1].NowError;
moto[2].Integral_speed=moto[2].Integral_speed+moto[2].NowError;
moto[3].Integral_speed=moto[3].Integral_speed+moto[3].NowError;	
	
moto[0].differential=moto[0].NowError-moto[0].LastError;
moto[1].differential=moto[1].NowError-moto[1].LastError;
moto[2].differential=moto[2].NowError-moto[2].LastError;
moto[3].differential=moto[3].NowError-moto[3].LastError;

moto[0].last_speed=moto[0].ActualSpeed;
moto[1].last_speed=moto[1].ActualSpeed;
moto[2].last_speed=moto[2].ActualSpeed;
moto[3].last_speed=moto[3].ActualSpeed;

moto[0].LastError=moto[0].NowError;
moto[1].LastError=moto[1].NowError;
moto[2].LastError=moto[2].NowError;
moto[3].LastError=moto[3].NowError;

moto[0].last_sum_count=moto[0].sum_count;
moto[1].last_sum_count=moto[1].sum_count;
moto[2].last_sum_count=moto[2].sum_count;
moto[3].last_sum_count=moto[3].sum_count;
}

void speed_PID(int wheelx,int pluse_speed)
{

	int i=wheelx-1;
	moto[i].set_speed=pluse_speed;
//	moto[1].set_speed=pluse_speed;
//	moto[2].set_speed=pluse_speed;
//	moto[3].set_speed=pluse_speed;
	
	
	moto[0].speed_kp=80.33;
	moto[0].speed_kd=0.151;
	moto[0].speed_ki=10.391;
	
	moto[1].speed_kp=86.33;
	moto[1].speed_kd=0.151;
	moto[1].speed_ki=10.391;
	
	moto[2].speed_kp=80.33;//49.33
	moto[2].speed_kd=0.151;
	moto[2].speed_ki=10.391;
	
	moto[3].speed_kp=90.33;
	moto[3].speed_kd=0.151;
	moto[3].speed_ki=20.391;

	moto[i].OutputValue=moto[i].speed_kp*moto[i].NowError+(float)moto[i].Integral_speed*moto[i].speed_ki+moto[i].differential*moto[i].speed_kd;
//	moto[1].OutputValue=moto[1].speed_kp*moto[1].NowError+(float)moto[1].Integral_speed*moto[1].speed_ki+moto[1].differential*moto[1].speed_kd;
//	moto[2].OutputValue=moto[2].speed_kp*moto[2].NowError+(float)moto[2].Integral_speed*moto[2].speed_ki+moto[2].differential*moto[2].speed_kd;
//	moto[3].OutputValue=moto[3].speed_kp*moto[3].NowError+(float)moto[3].Integral_speed*moto[3].speed_ki+moto[3].differential*moto[3].speed_kd;
	

//	if((int)moto[2].OutputValue<-1000)
//  moto[2].OutputValue=(float)(-1000);	
//	
//		if((int)moto[0].OutputValue<-1000)
//  moto[0].OutputValue=(float)(-1000);	
//		
//		if((int)moto[1].OutputValue<-1000)
//  moto[1].OutputValue=(float)(-1000);	
		
		if((int)moto[i].OutputValue<-1000)
  moto[i].OutputValue=(float)(-1000);	
		
//    if((int)moto[0].OutputValue>1000)
//		moto[0].OutputValue=(float)(1000);
//		
//		if((int)moto[1].OutputValue>1000)
//		moto[1].OutputValue=(float)(1000);	
//		
//		if((int)moto[2].OutputValue>1000)
//		moto[2].OutputValue=(float)(1000);	
		
		if((int)moto[i].OutputValue>1000)
		moto[i].OutputValue=(float)(1000);	
	if(i==2)
	{
		if(moto[2].set_speed>0)
	TIM_SetCompare3(TIM8,(int)moto[2].OutputValue);
	}
	if(i==0)
	{
		if(moto[0].set_speed>0)
  TIM_SetCompare1(TIM8,(int)moto[0].OutputValue);
	}
	if(i==1)
	{
		if(moto[1].set_speed>0)
	TIM_SetCompare2(TIM8,(int)moto[1].OutputValue);
	}
	if(i==3)
	{
		if(moto[3].set_speed>0)
	TIM_SetCompare4(TIM8,(int)moto[3].OutputValue);
	}
	if(i==0)
	{
		if(moto[0].set_speed<=0)
	TIM_SetCompare1(TIM8,1000+(int)moto[0].OutputValue);
	}
	if(i==1)
	{
		if(moto[1].set_speed<=0)
	TIM_SetCompare2(TIM8,1000+(int)moto[1].OutputValue);
	}
	if(i==2)
	{
		if(moto[2].set_speed<=0)
	TIM_SetCompare3(TIM8,1000+(int)moto[2].OutputValue);
	}
	if(i==3)
	{
		if(moto[3].set_speed<=0)
	TIM_SetCompare4(TIM8,1000+(int)moto[3].OutputValue);
	}
//		printf("moto[0].OutputValue=%d",moto[i].NowError);
		u3_printf("SPEED4=%d",moto[3].ActualSpeed);
		u3_printf("SPEED3=%d",moto[2].ActualSpeed);
	u3_printf("SPEED2=%d",moto[1].ActualSpeed);
	u3_printf("SPEED1=%d",moto[0].ActualSpeed);
//	printf("SPEED2=%ld\n\r\n\r",moto[4].ActualSpeed);
//		
//		
//		
//		
//		printf("OUT2=%d\n\r\n\r",(int)moto[0].OutputValue);
}


