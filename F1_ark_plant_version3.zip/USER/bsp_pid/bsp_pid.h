#ifndef  __BSP_PID_H
#define  __BSP_PID_H
#include "stm32f10x.h"
#include "bsp_wheel.h"
typedef struct
{
	float kp;
	
	float ki;
	
	float kd;
	
	int output;//����Ƚ�ֵ
	
	int maxOutput;
	
	int intput;
	
	int  integral;//����
	
	int set_point;//�趨ֵ
	
	float speed;
	
	float last_speed;
	
	float accelerated_speed;//���ٶ�
}PosCtrlType;

void brake(int set_count);

typedef struct{
	float Position_kp,Position_ki,Position_kd;
	float Increment_kp,Increment_ki,Increment_kd;
	float speed_kp,speed_ki,speed_kd;
	int count;
	long int sum_count;
	long int last_sum_count;
	int last_count;
	long int ActualSpeed;      	//��ǰ�ٶ�ֵ
	int16_t last_speed;         //�ϴ��ٶ�ֵ
  float OutputValue;        //���pwmռ�ձ�ֵ
	int16_t NowError;           //��ǰƫ��
	int16_t LastError;          //�ϴ�ƫ��	
	int16_t PrevError;		//���ϴ�ƫ��
	int16_t differential;
	int Integral_speed;   //������
	int set_speed;
}motor_control;

void PID_dispose(void);
void speed_PID(int wheelx,int pluse_speed);




#endif   