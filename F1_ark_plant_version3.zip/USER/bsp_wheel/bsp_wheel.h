#ifndef __BSP_USART3_H
#define __BSP_USART3_H
void wheel_staight(void);
void wheel_back(void);
void WHEEL_Init(void);
void wheel_left(void);
void wheel_right(void);
void wheel_stop(void);
void wheel_turn1(void);
void wheel_turn2(void);
void tim8_pwm_control(int dutyratio,int channel);
void spin_stop(void);
void spin_negative(void);
void spin_positive(void);
void pole_up(void);
void pole_down(void);
#include "stm32f10x.h"
#endif