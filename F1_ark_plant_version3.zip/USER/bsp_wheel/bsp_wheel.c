#include "bsp_wheel.h"
#include "bsp_pid.h"
/*PE7-PE14*/
int speed;
extern motor_control moto[4];

void WHEEL_Init(void)
{    	 
  GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		 //ʹ��PB,PE�˿�ʱ��
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	 
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE  );
  //��ʼ������
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_1|GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode =   GPIO_Mode_Out_PP; 	 //�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	 //IO���ٶ�Ϊ50MHz

	GPIO_Init(GPIOB, &GPIO_InitStructure);	
	GPIO_ResetBits(GPIOB,GPIO_Pin_13|GPIO_Pin_1|GPIO_Pin_0);
	/*C*/

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15|GPIO_Pin_3|GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode =   GPIO_Mode_Out_PP; 	 //�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	 //IO���ٶ�Ϊ50MHz

	GPIO_Init(GPIOC, &GPIO_InitStructure);	
	GPIO_ResetBits(GPIOC,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15|GPIO_Pin_3|GPIO_Pin_5);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode =   GPIO_Mode_Out_PP; 	 //�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	 //IO���ٶ�Ϊ50MHz

	GPIO_Init(GPIOA, &GPIO_InitStructure);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_11|GPIO_Pin_12);
	
	
}

void wheel_back(void)
{
		
	GPIO_ResetBits(GPIOC, GPIO_Pin_12);
	GPIO_ResetBits(GPIOA, GPIO_Pin_12);
	GPIO_ResetBits(GPIOA, GPIO_Pin_11);
	GPIO_ResetBits(GPIOB, GPIO_Pin_13);
	
	speed_PID(3,-speed);//80max,-6min
	speed_PID(2,-speed);
	speed_PID(4,-speed);
	speed_PID(1,-speed);
}

void wheel_staight(void)
{
	
	GPIO_SetBits(GPIOC, GPIO_Pin_12);
	GPIO_SetBits(GPIOA, GPIO_Pin_12);
	GPIO_SetBits(GPIOA, GPIO_Pin_11);
	GPIO_SetBits(GPIOB, GPIO_Pin_13);
	
	speed_PID(3,speed);//80max,-6min
	speed_PID(2,speed);
	speed_PID(4,speed);
	speed_PID(1,speed);
}

void wheel_left(void)
{	 
	GPIO_SetBits(GPIOC, GPIO_Pin_12);
	GPIO_ResetBits(GPIOA, GPIO_Pin_12);
	GPIO_ResetBits(GPIOA, GPIO_Pin_11);
	GPIO_SetBits(GPIOB, GPIO_Pin_13);
	speed_PID(1,speed);
	speed_PID(2,-speed);
	speed_PID(3,-speed);
	speed_PID(4,speed);
	
}

void wheel_right(void)
{	 
	GPIO_ResetBits(GPIOC, GPIO_Pin_12);
	GPIO_SetBits(GPIOA, GPIO_Pin_12);
	GPIO_SetBits(GPIOA, GPIO_Pin_11);
	GPIO_ResetBits(GPIOB, GPIO_Pin_13);
	speed_PID(1,-speed);
	speed_PID(2,speed);
	speed_PID(3,speed);
	speed_PID(4,-speed);
}
	
void wheel_stop(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_12);
	GPIO_ResetBits(GPIOA, GPIO_Pin_12);
	GPIO_ResetBits(GPIOA, GPIO_Pin_11);
	GPIO_ResetBits(GPIOB, GPIO_Pin_13);
	GPIO_ResetBits(GPIOC, GPIO_Pin_3);
	GPIO_ResetBits(GPIOC, GPIO_Pin_5);
	GPIO_ResetBits(GPIOC, GPIO_Pin_1);
	GPIO_ResetBits(GPIOC, GPIO_Pin_2);
	GPIO_ResetBits(GPIOB, GPIO_Pin_0);
	GPIO_ResetBits(GPIOB, GPIO_Pin_1);
	
	
	TIM_SetCompare1(TIM8,1000);
	TIM_SetCompare2(TIM8,1000);
	TIM_SetCompare3(TIM8,1000);
	TIM_SetCompare4(TIM8,1000);
}

void wheel_turn1(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_12);
	GPIO_SetBits(GPIOA, GPIO_Pin_12);
	GPIO_ResetBits(GPIOA, GPIO_Pin_11);
	GPIO_SetBits(GPIOB, GPIO_Pin_13);
	speed_PID(1,-speed);
	speed_PID(2,speed);
	speed_PID(3,-speed);
	speed_PID(4,speed);
}

void wheel_turn2(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_8);
	GPIO_SetBits(GPIOE, GPIO_Pin_10);
	GPIO_SetBits(GPIOE, GPIO_Pin_11);
	GPIO_SetBits(GPIOE, GPIO_Pin_13);
	GPIO_ResetBits(GPIOE, GPIO_Pin_7);
	GPIO_ResetBits(GPIOE, GPIO_Pin_9);
	GPIO_ResetBits(GPIOE, GPIO_Pin_12);
	GPIO_ResetBits(GPIOE, GPIO_Pin_14);
}

void spin_positive(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_3);
	GPIO_ResetBits(GPIOC, GPIO_Pin_5);
}

void spin_negative(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_5);
	GPIO_ResetBits(GPIOC, GPIO_Pin_3);
}

void spin_stop(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_5);
	GPIO_ResetBits(GPIOC, GPIO_Pin_3);
}


void pole_up()
{
	GPIO_ResetBits(GPIOB, GPIO_Pin_0);
	GPIO_SetBits(GPIOB, GPIO_Pin_1);
}

void pole_down()
{
	GPIO_ResetBits(GPIOB, GPIO_Pin_1);
	GPIO_SetBits(GPIOB, GPIO_Pin_0);
}


/*1-100*/
void tim8_pwm_control(int dutyratio,int channel)
{
	int i;
	i=dutyratio;
	if (channel==1)
		TIM_SetCompare1(TIM8,i);
	if (channel==2)
		TIM_SetCompare2(TIM8,i);
	if (channel==3)
		TIM_SetCompare3(TIM8,i);
	if (channel==4)
		TIM_SetCompare4(TIM8,i);
	
}