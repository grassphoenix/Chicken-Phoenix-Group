#include "bsp_stepping.h"
#include "usart.h"
/**
  ******************************************************************************
  * @file    bsp_stepping.c
	* @author  grass chichen phoenix company
	* @version V1.4.0
	* @date    02-June-2021
	* @brief   control stepping motor and feedback the accarcy circle adn position
	* @attenion
	* please homing the stepping motor angle to zero before use the fuction
	* you can set zero by your hand or use the sensor 
	* please be sure the stepping motor have not been run before use fuctions
  ******************************************************************************
*/

int pluse1,pluse2;//command pluse
int sum_pluse1,sum_pluse2;//now accarcy from 32 start up to now
int spin_rotation1,spin_rotation2;

/**
  * @brief control stepping motor1 accarcy step and spin rotation
  * @param pluse:control step 
  * @param spin_rotation: controle stepping motor spin rotation
           this parammeter can be:  clockwise or anticlockwise
  * @return unfinshed or finshed;finshed:has been finshed last
	          order,unfinshed:has not finshed last order can'toperat
	* @retval None
  */
int stepping1_run(int pluse,int spin_rotation)
{ 
		spin_rotation1=spin_rotation;//record the spin rotatiom
//	if(pluse1<=0)//means that last command has been over
//	 {
		 pluse1=pluse;
//		 return finshed;
//	 }
//	else if(pluse1>0);
//		return unfinshed;//can't operat
}

/**
  * @brief control stepping motor2 accarcy step and spin rotation
  * @param pluse:control step 
  * @param spin_rotation: controle stepping motor spin rotation
           this parammeter can be:  clockwise or anticlockwise
  * @return unfinshed or finshed;finshed:has been finshed last
	          order,unfinshed:has not finshed last order can'toperat
	* @retval None
  */
int stepping2_run(int pluse,int spin_rotation)
{ 
		spin_rotation2=spin_rotation;//record the spin rotatiom
	if(pluse2<=0)//means that last command has been over
	 {
		 pluse2=pluse;
		 return finshed;
	 }
	else if(pluse2>0)
		return unfinshed;//can't operat
}

/**
  * @brief scanf stepping state
  * @return unfinshed or finshed;finshed:has been finshed last
	          order,unfinshed:has not finshed last order can'toperat
            finshed=1;unfinshed=0;
	* @retval None
  */

int scanf_state1()
{
	if(pluse1<=0)
		return finshed;
	if(pluse1>0)
		return unfinshed;
}

/**
  * @brief scanf stepping state
  * @return unfinshed or finshed;finshed:has been finshed last
	          order,unfinshed:has not finshed last order can'toperat
            finshed=1;unfinshed=0;
	* @retval None
  */

int scanf_state2()
{
	if(pluse2<=0)
		return finshed;
	if(pluse2>0)
		return unfinshed;
}

/**
  * @brief  make accarcy pluse to sttepping motor1
  * @param  pluse:accarcy pluse
	* @retval None
  */
void stepping_motor1_accarcy_pluse(int pluse)
{
	int i;
	pluse=(int)pluse;
	i=pluse-sum_pluse1;
	if(i>=0)
	stepping1_run(i,1);
	if(i<0)
	stepping1_run((-i),0);
}

/**
  * @brief  make accarcy pluse to sttepping motor2
  * @param  pluse:accarcy pluse
	* @retval None
  */
void stepping_motor2_accarcy_pluse(int pluse)
{
	int i;
	pluse=(int)pluse;
	i=pluse-sum_pluse2;
	if(i>=0)
	stepping2_run(i,1);
	if(i<0)
	stepping2_run((-i),0);
}

/**
  * @brief  get accarcy angle
  * @param  stepping_number:which steping_motor
            this parammeter can be: 1 or 2
  * @param  this stepping motor's step angle
	* @retval None
  */

float get_angle(int stepping_number,float step_angle)
{
	float i;
	int j;
	int k;
	float l;
	j=360/step_angle;

	if(stepping_number==1)
	{
		i=(sum_pluse1*step_angle);
			
		j=i*10;
		k=j%3600;
		l=(float)k/10;
//		printf("l=%f\n\r\n\r",l);
	}
	if(stepping_number==2)
	{
		i=(sum_pluse1*step_angle);
			
		j=i*10;
		k=j%3600;
		l=(float)k/10;
	}
	return l;
}

/**
  * @brief  make accarcy abgle to sttepping motor1
  * @param  angle:accarcy angle
  * @param  step angle:stepping motor's step angle
	* @retval None
  */

void stepping_motor1_accarcy_angle(int angle,float step_angle)
{
	float i;
	i=get_angle(1,step_angle);
	if((angle-i)<=180&&(angle-i)>=0)
	stepping_motor1_accarcy_pluse(sum_pluse1+(int)((angle-i)/step_angle));
//	printf("%d\n\r\n\r",sum_pluse1+(int)((angle-i)/step_angle));
	if((angle-i)>180&&(angle-i)<=360)
	stepping_motor1_accarcy_pluse(sum_pluse1-(int)(360/step_angle)+(int)(angle-i)/step_angle);
	if((angle-i)<0&&(angle-i)>=-180)
	stepping_motor1_accarcy_pluse(sum_pluse1+(int)((angle-i)/step_angle));
	if((angle-i)<-180&&(angle-i)>=-360)
	stepping_motor1_accarcy_pluse(sum_pluse1+(int)(360/step_angle)+(int)(angle-i)/step_angle);
}

/**
  * @brief  make accarcy abgle to sttepping motor2
  * @param  angle:accarcy angle
  * @param  step angle:stepping motor's step angle
	* @retval None
  */

void stepping_motor2_accarcy_angle(int angle,float step_angle)
{
	float i;
	i=get_angle(2,step_angle);
	if((angle-i)<=180&&(angle-i)>=0)
	stepping_motor2_accarcy_pluse(sum_pluse1+(int)(angle-i)/step_angle);
	if((angle-i)>180&&(angle-i)<=360)
	stepping_motor2_accarcy_pluse(sum_pluse1-(int)(360/step_angle)+(int)(angle-i)/step_angle);
	if((angle-i)<0&&(angle-i)>=-180)
	stepping_motor2_accarcy_pluse(sum_pluse1+(int)(angle-i)/step_angle);
	if((angle-i)<-180&&(angle-i)>=-360)
	stepping_motor2_accarcy_pluse(sum_pluse1+(int)(360/step_angle)+(int)(angle-i)/step_angle);
}

