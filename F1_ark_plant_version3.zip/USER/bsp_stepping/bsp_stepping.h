#ifndef  BSP_STEPPING_H
#define  BSP_STEPPING_H
#include "stm32f10x.h"
#define clockwise 1;//˳ʱ��
#define anticlockwise 0;//��ʱ��
#define unfinshed 0 //δ�����һ��ָ��
#define finshed 1 //�������һ��ָ��
int stepping1_run(int pluse,int spin_rotation);
int stepping2_run(int pluse,int spin_rotation);
int scanf_state1(void);
int scanf_state2(void);
void stepping_motor1_accarcy_pluse(int pluse);
void stepping_motor2_accarcy_pluse(int pluse);
float get_angle(int stepping_number,float step_angle);
void stepping_motor1_accarcy_angle(int angle,float step_angle);
void stepping_motor2_accarcy_angle(int angle,float step_angle);
#endif
