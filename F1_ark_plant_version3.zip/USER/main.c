#include "stm32f10x.h"
#include "usart.h"
#include "usart.h"
#include "usart3.h"
#include "bsp_timer.h"
#include "bsp_wheel.h"
#include "delay.h"
#include "bsp_stepping.h"
#include "bsp_encoder.h"
#include "bsp_pid.h"
/*PC13���뷽��PC14��������
 *PC15��ȡ����,PC0��ȡ����
 *PC1:�����A��PC2:�����B
 *PC6,PC7,PC8,PC9PWM1,2,3,4
 *int2a:PC12,int2b:PA12,int2c:PA11,int2d:PB13
 *��������PB3,PA15;PB4,PB5;PB6,PB7;PA0,PA1
 *��ת��PC3,PC5
*/
extern char order;
void usart3_init(u32 bound);	
extern int timer_delay;
#define USART3_MAX_RECV_LEN		600	
extern int speed;
extern u8  USART3_RX_BUF[USART3_MAX_RECV_LEN];
extern int pluse1,pluse2;
extern int sum_pluse1,sum_pluse2;
extern motor_control moto[4];
extern int cnt2;
extern int cnt1,cnt2,cnt3,cnt4;
int spin_state=0;
int turn_state=0;

 int main(void)
 {	
	 int k=1;
	 float j;
	 pluse1=0;
	 pluse2=0;
	 speed=0;
	 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
   WHEEL_Init();
	 PWM_timer8_Init(1000-1,71-1);
	 usart3_init(9600);
   uart_init(115200);
	 encoder1_tim2_init();
   encoder2_tim3_init();
   encoder3_tim4_init();
   encoder4_tim5_init();
	 stepping1_tim6_init(450-1,740-1);
	 stepping2_tim7_init(450-1,750-1);
	 timer1_Init(100-1,7400-1);
	 TIM_SetCompare1(TIM8,0);
	 TIM_SetCompare2(TIM8,0);
	 TIM_SetCompare3(TIM8,0);
	 TIM_SetCompare4(TIM8,0);
	 moto[1].count=0;
	 moto[0].count=0;
	 moto[2].count=0;
	 moto[3].count=0;
	 moto[0].sum_count=0;
	 moto[1].sum_count=0;
	 moto[2].sum_count=0;
	 moto[3].sum_count=0;
	wheel_stop();
	speed=70;
 while(1)
	{	
		
//		wheel_back();
		printf("pluse2=%d\n\r\n\r",pluse2);
		
	  if(scanf_state1()==1)
	  {
//	    printf("%c\n\r\n\r",order);
			
			
		  if(order=='8')
			{
		    stepping_motor1_accarcy_angle(0,0.9);
			  if(pluse1<=3)
				{
					GPIO_SetBits(GPIOC, GPIO_Pin_2);
//				  delay_ms(10);
					
					
				}
			}
			
			
		  if(order=='7')
			{
	  	  stepping_motor1_accarcy_angle(45,0.9);
				if(pluse1<=3)
				{
					GPIO_SetBits(GPIOC, GPIO_Pin_2);
//				  delay_ms(10);
					
					
				}
			}
			
			
	  	if(order=='4')
	  	{
				stepping_motor1_accarcy_angle(90,0.9);
				if(pluse1<=3)
				{
					GPIO_SetBits(GPIOC, GPIO_Pin_2);
//				  delay_ms(10);
					
					
				}
			}
			
			
	  	if(order=='1')
			{
	  	  stepping_motor1_accarcy_angle(135,0.9);
				if(pluse1<=3)
				{
					GPIO_SetBits(GPIOC, GPIO_Pin_2);
					
//				  delay_ms(10);
					
				}
			}
			
			
	    if(order=='2')
			{
	    	stepping_motor1_accarcy_angle(180,0.9);
				if(pluse1<=3)
				{
						GPIO_SetBits(GPIOC, GPIO_Pin_2);
//				  delay_ms(10);
					
					
				}
			
			}
			
			
	    if(order=='3')
			{
	    	stepping_motor1_accarcy_angle(225,0.9);
				if(pluse1<=3)
				{
					GPIO_SetBits(GPIOC, GPIO_Pin_2);
//				  delay_ms(10);
					
					
				}
			}
			
			
	  	if(order=='6')
			{
	     	stepping_motor1_accarcy_angle(270,0.9);
				if(pluse1<=3)
				{
					GPIO_SetBits(GPIOC, GPIO_Pin_2);
//				  delay_ms(10);
					
					
				}
			}
			
			
	  	if(order=='9')
			{
		    stepping_motor1_accarcy_angle(315,0.9);
				if(pluse1<=3)
				{
					GPIO_SetBits(GPIOC, GPIO_Pin_2);
//				  delay_ms(10);
					
					
				}
			}			
	  }
		
		if(order=='5')
		{
			GPIO_SetBits(GPIOC, GPIO_Pin_1);
//			delay_ms(10);
			
			
		}

		if(order=='A')
			wheel_staight();
		if(order=='B')
			wheel_back();
		if(order=='C')
			wheel_left();
		if(order=='D')
			wheel_right();
		if(order=='F')
			wheel_stop();
		
		if(order=='E'&&spin_state==0)
		{
			stepping_motor2_accarcy_pluse(957);
		  
			if(scanf_state2()==1)
			{   
				pole_up();  
			  spin_state=1;
				order='0';
			}
			
		}
//			 u3_printf("SPEED3=%d",moto[2].ActualSpeed);
		if(order=='E'&&spin_state==1)
		{
			void pole_down();
			stepping_motor2_accarcy_pluse(888);
			if(scanf_state2()==1)
			{ 
			    spin_state=0;
				  order='0';
				
			}
		}
		
		if(order=='G'&&turn_state==0)
		{
			wheel_turn1();
			 turn_state=1;
			 order='0';		
		}
		
			if(order=='G'&&turn_state==1)
		{
			wheel_turn2();
			 turn_state=0;
			 order='0';
		}

		
		if(order=='H')  	speed=30;
		if(order=='I')    speed=70;
		if(order=='J')    pole_up();  
		if(order=='K')    pole_down();

//	 u3_printf("SPEED4=%d",moto[3].ActualSpeed);
  }
}

